# IMPORTABT NOTE
Light bridge part of assignment renamed as "Arduino Part". Light bridge folder contains previous version